<html>
	<head>
		<title>
                        Servers monitor - Dashboard
                </title>
		<style>	
			body{
				margin-left: auto;
				margin-right: auto;
				width: 1200px;
			}
	
			body #DLeft {
				float: left;
				margin-top: 20px;
				width: 300px;
			}

			body #DRight {
				float: right;
				margin-top: 20px;
				width: 880px;
        		}
		</style>
	</head>

	<body>
		<div id=title>
			<?php
				include_once 'include/title.php';
			?>
		</div>
		<div id=DLeft>
			<?php			
				include_once 'include/menu.php';
			?>
		</div>
		<div id=DRight>
			<?php
				include_once 'include/history-linux-memory.php';
			?>
		</div>
		<div id=footer>
			<?php
                		include_once 'include/footer.php';
        		?>
		</div>
	<body>
<html>

