<!DOCTYPE html>
<html>
<head>
<title>Creating Dynamic Data Graph using PHP and Chart.js</title>
<style type="text/css">

#chart-ram {
    width: 100%;
}
</style>
<script type="text/javascript" src="graphic/js/jquery.min.js"></script>
<script type="text/javascript" src="graphic/js/Chart.min.js"></script>


</head>
<body>
    <div id="chart-ram">
        <canvas id="graphCanvas"></canvas>
    </div>

    <script>
        $(document).ready(function () {
            showGraph();
        });


        function showGraph()
        {
            {
                $.post("graphic/data_ram.php",
                function (data)
                {
                    console.log(data);
                    var HOUR = [];
                    var RAM = [];

                    for (var i in data) {
                        HOUR.push(data[i].hour);
                        RAM.push(data[i].usedram);
                    }

                    var chartdata = {
                        labels: HOUR,
                        datasets: [
                            {
                                label: 'RAM memory used (in MB)',
                                backgroundColor: '#49e2ff',
                                borderColor: '#46d5f1',
                                hoverBackgroundColor: '#CCCCCC',
                                hoverBorderColor: '#666666',
                                data: RAM
                            }
                        ]
                    };

			var options = {
            			legend: {
                		display: true
            			},
            			scales: {
                			xAxes: [{
                    				display: true
                			}],
             				yAxes: [{
                    				ticks: {
                        				beginAtZero: true
                    				}
                			}]
            			}
        		};

                    	var graphTarget = $("#graphCanvas");

                    	var barGraph = new Chart(graphTarget, {
                        	type: 'bar',
                        	data: chartdata,
				options: options
                    	});
                });
		}
        	}
        </script>

</body>
</html>
