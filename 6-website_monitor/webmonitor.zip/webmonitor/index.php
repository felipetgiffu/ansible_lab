<html>
	<head>
		<title>
                        Red Hat Server monitor - Dashboard
                </title>
		<style>	
			body{
				margin-left: auto;
				margin-right: auto;
				width: 1200px;
			}
	
			body #DLeft {
				float: left;
				margin-top: 50px;
				text-align: right;
				width: 300px;
			}

			body #DRight {
				float: right;
				margin-top: 20px;
				width: 880px;
        		}
		</style>
	</head>
	<?php
		require_once 'connection/connectDB.php';
		$sql = "SELECT * FROM squadinfo";

		$result = mysqli_query($link, $sql);
		mysqli_num_rows($result);
        	$row = mysqli_fetch_array($result);
		$_LOGO = $row['squadlogo'];

	?>	
	<body>
		<div id=title>
			<?php
				include_once 'include/title.php';
			?>
		</div>
		<div id=DLeft>
			<?php			
				include_once 'include/menu.php';
			?>
		</div>
		<div id=DRight>
			<?php
				include_once 'include/linux-home-content.php';
			?>
		</div>
		<div id=footer>
			<?php
                		include_once 'include/footer.php';
        		?>
		</div>
	<body>
<html>

