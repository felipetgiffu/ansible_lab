#!/bin/bash
#

## VARIABLES
_DB_USER=root
_DB_NAME=monitor
_TABLEMEMORY=memory
_TABLECPU=cpu
_TABLEHOST=hostdetails
_DIR=/var/www/html/webmonitor
_SERVERLIST=$_DIR/serverList.txt

## Inserir dados nas tabelas CPU e MEMORY
exec 3< $_SERVERLIST
        while read hostname <&3; do

                _hostname=$(awk -F'[<>]' '/<hostname>/{print $3}' $_DIR/xml/$hostname.xml)
                _year=$(cat $_DIR/xml/$hostname.xml | awk -F'[<>]' '/<date>/{print $3}' | cut -c1-4)
                _month=$(cat $_DIR/xml/$hostname.xml | awk -F'[<>]' '/<date>/{print $3}' | cut -c6-7)
                _day=$(cat $_DIR/xml/$hostname.xml | awk -F'[<>]' '/<date>/{print $3}' | cut -c9-10)
                _hour=$(cat $_DIR/xml/$hostname.xml | awk -F'[<>]' '/<date>/{print $3}' | cut -c12-16)
                _totalram=$(awk -F'[<>]' '/<ramtotal>/{print $3}' $_DIR/xml/$hostname.xml)
                _usedram=$(awk -F'[<>]' '/<ramused>/{print $3}' $_DIR/xml/$hostname.xml)
                _totalswap=$(awk -F'[<>]' '/<swaptotal>/{print $3}' $_DIR/xml/$hostname.xml)
                _usedswap=$(awk -F'[<>]' '/<swapused>/{print $3}' $_DIR/xml/$hostname.xml)
                _totalcpu=$(cat $_DIR/xml/$hostname.xml | awk -F'[<>]' '/<cpu>/{print $3}')
                _usedcpu=$(cat $_DIR/xml/$hostname.xml | awk -F'[<>]' '/<cpuavg>/{print $3}' | sed 's/\%//g')

                mysql -u $_DB_USER -D $_DB_NAME -e "INSERT INTO $_TABLEMEMORY (server, year, month, day, hour, totalram, usedram, totalswap, usedswap) VALUES ('$_hostname','$_year','$_month','$_day','$_hour','$_totalram','$_usedram','$_totalswap','$_usedswap')"

                mysql -u $_DB_USER -D $_DB_NAME -e "INSERT INTO $_TABLECPU (server, year, month, day, hour, totalcpu, usedcpu) VALUES ('$_hostname','$_year','$_month','$_day','$_hour','$_totalcpu','$_usedcpu')"


        done
exec 3<&-


## Zerar tabela hostdetails
mysql -u $_DB_USER -D $_DB_NAME -e "TRUNCATE TABLE hostdetails"

## Inserir dados na tabela hostdetails
exec 3< $_SERVERLIST
        while read server_name <&3; do

		hostname=$server_name

                _hostname=$(awk -F'[<>]' '/<hostname>/{print $3}' $_DIR/xml/$hostname.xml)
                _date=$(awk -F'[<>]' '/<date>/{print $3}' $_DIR/xml/$hostname.xml)
		_ip=$(awk -F'[<>]' '/<ip>/{print $3}' $_DIR/xml/$hostname.xml)
                _osname=$(awk -F'[<>]' '/<osname>/{print $3}' $_DIR/xml/$hostname.xml)
                _osversion=$(awk -F'[<>]' '/<osversion>/{print $3}' $_DIR/xml/$hostname.xml)
                _kernel=$(awk -F'[<>]' '/<kernel>/{print $3}' $_DIR/xml/$hostname.xml)
                _platform=$(awk -F'[<>]' '/<platform>/{print $3}' $_DIR/xml/$hostname.xml)
                _uptime=$(awk -F'[<>]' '/<uptime>/{print $3}' $_DIR/xml/$hostname.xml)
                _load=$(awk -F'[<>]' '/<load>/{print $3}' $_DIR/xml/$hostname.xml)
                _userLog=$(awk -F'[<>]' '/<userLog>/{print $3}' $_DIR/xml/$hostname.xml)
                _ssh=$(awk -F'[<>]' '/<ssh>/{print $3}' $_DIR/xml/$hostname.xml)
                _ramtotal=$(awk -F'[<>]' '/<ramtotal>/{print $3}' $_DIR/xml/$hostname.xml)
                _ramused=$(awk -F'[<>]' '/<ramused>/{print $3}' $_DIR/xml/$hostname.xml)
                _swaptotal=$(awk -F'[<>]' '/<swaptotal>/{print $3}' $_DIR/xml/$hostname.xml)
                _swapused=$(awk -F'[<>]' '/<swapused>/{print $3}' $_DIR/xml/$hostname.xml)
                _cpu=$(awk -F'[<>]' '/<cpu>/{print $3}' $_DIR/xml/$hostname.xml)
                _cpuavg=$(awk -F'[<>]' '/<cpuavg>/{print $3}' $_DIR/xml/$hostname.xml)

		mysql -u $_DB_USER -D $_DB_NAME -e "INSERT INTO $_TABLEHOST (server, date, ip, osname, osversion, kernel, platform, uptime, load_avg, userlog, ssh, ramtotal, ramused, swaptotal, swapused, cpu, cpuavg) VALUES ('$_hostname','$_date','$_ip','$_osname','$_osversion','$_kernel','$_platform','$_uptime','$_load','$_userLog','$_ssh','$_ramtotal','$_ramused','$_swaptotal','$_swapused','$_cpu','$_cpuavg')"

        done
exec 3<&-

