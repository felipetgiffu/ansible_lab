#!/bin/bash
#

# Variables
tmp_dir=/tmp/monitorfiles
xmlFile=$tmp_dir/$(hostname -s).xml
xmlFileFS=$tmp_dir/$(hostname -s)-filesystem.xml
fileSystem=$tmp_dir/filesystem.txt
date=$(date +'%Y-%m-%d_%H-%M')
#emailList=ralex@br.ibm.com


# Create temp directory
mkdir -p $tmp_dir

# Create the XML file
echo '<?xml version="1.0" encoding="UTF-8"?>' > $xmlFile
echo >> $xmlFile

echo "<server>" >> $xmlFile

#Date
echo "<date>$(date +'%Y-%m-%d %R %Z')</date>" >> $xmlFile

# IP address
echo "<ip>$(hostname -I )</ip>" >> $xmlFile

# Hostname
echo "<hostname>$(hostname -s)</hostname>" >> $xmlFile

# OS Version
echo "<osname>$(cat /etc/os-release | grep PRETTY_NAME | sed 's/\PRETTY_NAME="//g' | sed 's/\"//g')</osname>" >> $xmlFile
echo "<osversion>$(cat /etc/os-release | grep VERSION_ID | sed 's/\VERSION_ID="//g' | sed 's/\"//g')</osversion>" >> $xmlFile

# Kernel version
echo "<kernel>$(uname -r)</kernel>" >> $xmlFile

# Hardware platform
echo "<platform>$(uname -i)</platform>" >> $xmlFile

# Uptime
echo "<uptime>$(uptime | awk '{print $3,$4}' | sed "s/\,//g")</uptime>" >> $xmlFile

# Load average
echo "<load>$(cat /proc/loadavg | awk '{print $1, $2, $3}')</load>" >> $xmlFile

# Logged users
echo "<userLog>$(w | grep -v average | grep -v USER | grep -v ansible |  awk '{printf $1 " "}')</userLog>" >> $xmlFile

# SSH Service
echo "<ssh>$(systemctl status sshd.service | grep Active | awk '{print $2,$3}')</ssh>" >> $xmlFile

# RAM Memory
echo "<ramtotal>$(free -m | awk '{print $1,$2}' | grep -v Swap | grep -v total | sed 's/\Mem: //g' | grep -v +)</ramtotal>" >> $xmlFile
echo "<ramused>$(free -m | awk '{print $1,$3}' | grep -v Swap | grep -v total | sed 's/\Mem: //g' | grep -v +)</ramused>" >> $xmlFile

# SWAP
echo "<swaptotal>$(free -m | awk '{print $1,$2}' | grep -v Mem | grep -v total | sed 's/\Swap: //g' | grep -v +)</swaptotal>" >> $xmlFile
echo "<swapused>$(free -m | awk '{print $1,$3}' | grep -v Mem | grep -v total | sed 's/\Swap: //g' | grep -v +)</swapused>" >> $xmlFile

#CPU
echo "<cpu>$(lscpu | grep 'CPU(s):' | grep -v NUMA | awk '{print $2}')</cpu>" >> $xmlFile
echo "<cpuavg>$(sar 1 10 | grep Average | awk '{printf (100-$8"%")}')</cpuavg>" >> $xmlFile

## Create file with list of file systems available
df -h | grep -v tmpfs | awk '{print $6}' | grep -v Mounted | grep -v gsa | grep -v export > $fileSystem

# File system

echo '<?xml version="1.0" encoding="UTF-8"?>' > $xmlFileFS
echo >> $xmlFileFS

echo "<server>" >> $xmlFileFS

exec 3< $fileSystem
while read file <&3; do

	echo "<filesystem>" >> $xmlFileFS
	echo "<fs>" >> $xmlFileFS

	# File system name
	echo "<name>$(df -h $file | grep -v tmpfs | awk '{print $6}' | grep -v Mounted)</name>" >> $xmlFileFS
	echo "<size>$(df -h $file | grep -v tmpfs | awk '{print $2}' | grep -v Size)</size>" >> $xmlFileFS
	echo "<used>$(df -h $file | grep -v tmpfs | awk '{print $3}' | grep -v Used)</used>" >> $xmlFileFS
	echo "<available>$(df -h $file | grep -v tmpfs | awk '{print $4}' | grep -v Avail)</available>" >> $xmlFileFS
	echo "<percUsed>$(df -h $file | grep -v tmpfs | awk '{print $5}' | grep -v Use | sed 's/\%//g')</percUsed>" >> $xmlFileFS
	echo "</fs>" >> $xmlFileFS
	echo "</filesystem>" >> $xmlFileFS

	# Check if the file system has more 80% used and is sent an email is true the condition
	if [ $(df -h $file | grep -v tmpfs | awk '{print $5}' | grep -v Use | sed 's/\%//g') -ge 80 ]; then

		# If the file system has more 80%, add the file system in the following file to control the email notification
		echo $file >> /tmp/filesystem_status_$(date +'%Y-%m-%d')
	fi
done
exec 3<&-

echo "</server>" >> $xmlFile
echo "</server>" >> $xmlFileFS

chmod 775 $xmlFile
chmod 775 $xmlFileFS

# echo "<>$()</>" >> $xmlFile
