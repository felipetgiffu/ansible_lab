<?php

	$_DAY = $_GET['day'];
	$_MONTH = $_GET['month'];
        $_YEAR = $_GET['year'];
        $_SERVER = $_GET['server'];
	
	$_avgRAM = 0;
        $_avgRAMPERC = 0;
        $_avgSWAP = 0;
        $_avgSWAPPERC = 0;
        $_totalHOUR = 0;

	$host = "localhost";
        $username = "root";
        $password = "";
        $dbname = "monitor";

        // Create connection
        $link = mysqli_connect($host, $username, $password, $dbname);

        // Check connection
        if (!$link) {
                echo "Error: Unable to connect to MySQL." . PHP_EOL;
                echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
                echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
                exit;
        }

	$sql = "SELECT * FROM memory WHERE year='$_YEAR' AND server='$_SERVER' AND month='$_MONTH' AND day='$_DAY' ORDER BY hour DESC";

    	$dadosXls  = "";
    	$dadosXls .= "  <table border='1'>";
	$dadosXls .= "          <tr align=center>";
        $dadosXls .= "                  <th colspan=7>MEMORY REPORT</th>";
        $dadosXls .= "          </tr>";
	$dadosXls .= "          <tr>";
        $dadosXls .= "                  <th colspan=7>&nbsp;</th>";
        $dadosXls .= "          </tr>";
	$dadosXls .= "		<tr>";
	$dadosXls .= "          	<th>Server:</th>";
	$dadosXls .= "                  <th colspan=2>$_SERVER</th>";
	$dadosXls .= "                  <th>&nbsp;</th>";
	$dadosXls .= "                  <th>Day:</th>";
	$dadosXls .= "                  <th colspan=2>$_MONTH / $_DAY / $_YEAR</th>";
	$dadosXls .= "      	</tr>";
	$dadosXls .= "          <tr>";
	$dadosXls .= "                  <th colspan=7>&nbsp;</th>";
	$dadosXls .= "          </tr>";
	$dadosXls .= "          <tr align=center>";
    	$dadosXls .= "          	<th width:20%>Hour</th>";
    	$dadosXls .= "          	<th>Total RAM (MB)</th>";
    	$dadosXls .= "          	<th>Used RAM (MB)</th>";
	$dadosXls .= "                  <th>% Used RAM</th>";
	$dadosXls .= "                  <th>Total SWAP (MB)</th>";
	$dadosXls .= "                  <th>Used Used (MB)</th>";
	$dadosXls .= "                  <th>% Used SWAP</th>";
    	$dadosXls .= "      	</tr>";

	if($result = mysqli_query($link, $sql)){
        	if(mysqli_num_rows($result) > 0){
                	while($row = mysqli_fetch_array($result)){
				$_ramusedperc = ($row['usedram']/$row['totalram'])*100;
				$_swapusedperc = ($row['usedswap']/$row['totalswap'])*100;
				$_avgRAM = $_avgRAM + $row['usedram'];
                                $_avgSWAP = $_avgSWAP + $row['usedswap'];
                                $_totalHOUR ++;

				$_avgRAMPERC = $_avgRAMPERC + $_ramusedperc;
				$_avgSWAPPERC = $_avgSWAPPERC + $_swapusedperc;

   	     			$dadosXls .= "      <tr align=center>";
        			$dadosXls .= "          <td>".$row['hour']."</td>";
        			$dadosXls .= "          <td>".$row['totalram']."</td>";
        			$dadosXls .= "          <td>".$row['usedram']."</td>";
				$dadosXls .= "          <td>".number_format($_ramusedperc, 2, '.', '')."%</td>";
				$dadosXls .= "          <td>".$row['totalswap']."</td>";
				$dadosXls .= "          <td>".$row['usedswap']."</td>";
				$dadosXls .= "          <td>".number_format($_swapusedperc, 2, '.', '')."%</td>";
        			$dadosXls .= "      </tr>";
			}
		}
    	}
	$dadosXls .= "          <tr>";
        $dadosXls .= "                  <th colspan=7>&nbsp;</th>";
        $dadosXls .= "          </tr>";
	$dadosXls .= "          <tr align=center>";
        $dadosXls .= "                  <th colspan=2>Average RAM and SWAP</th>";
	$dadosXls .= "          	<td>".number_format($_avgRAM/$_totalHOUR, 2, '.', '')."</td>";
	$dadosXls .= "                  <td>".number_format($_avgRAMPERC/$_totalHOUR, 2, '.', '')."%</td>";
	$dadosXls .= "          	<td>&nbsp;</td>";
	$dadosXls .= "                  <td>".number_format($_avgSWAP/$_totalHOUR, 2, '.', '')."</td>";
	$dadosXls .= "                  <td>".number_format($_avgSWAPPERC/$_totalHOUR, 2, '.', '')."%</td>";
        $dadosXls .= "          </tr>";
	$dadosXls .= "          <tr>";
        $dadosXls .= "                  <th colspan=7>&nbsp;</th>";
        $dadosXls .= "          </tr>";
	$dadosXls .= "          <tr>";
        $dadosXls .= "                  <th colspan=7 align=left>MB = Megabytes</th>";
        $dadosXls .= "          </tr>";
	$dadosXls .= "          <tr>";
        $dadosXls .= "                  <th colspan=7>&nbsp;</th>";
        $dadosXls .= "          </tr>";
    	$dadosXls .= "  </table>";
 
    	$arquivo = "Memory_report-$_SERVER.xls";  
    
	// Configurações header para forçar o download  
    	header('Content-Type: application/vnd.ms-excel');
    	header('Content-Disposition: attachment;filename="'.$arquivo.'"');
    	header('Cache-Control: max-age=0');
	header ("Content-Description: PHP Generated Data" );    
	// Se for o IE9, isso talvez seja necessário
    	header('Cache-Control: max-age=1');

        header ("Last-Modified: " . gmdate("D,d M YH:i:s") . " GMT");
       
    	// Envia o conteúdo do arquivo  
    	echo $dadosXls;  
    	exit;

?>
