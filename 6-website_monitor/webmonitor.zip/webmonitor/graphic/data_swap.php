<?php

	session_start();

	header('Content-Type: application/json');

	$_DAY = $_SESSION['day'];
        $_MONTH = $_SESSION['month'];
        $_YEAR = $_SESSION['year'];
        $_SERVER = $_SESSION['server'];

	$conn_swap = mysqli_connect("localhost","root","","monitor");

	$sqlQuery_swap = "SELECT * FROM memory WHERE year='$_YEAR' AND server='$_SERVER' AND month='$_MONTH' AND day='$_DAY' ORDER BY hour ASC";

	$result_swap = mysqli_query($conn_swap,$sqlQuery_swap);

	$data = array();
	foreach ($result_swap as $row_swap) {
		$data_swap[] = $row_swap;
	}

	mysqli_close($conn_swap);

	echo json_encode($data_swap);

?>
