<?php

	session_start();

	header('Content-Type: application/json');

	$_DAY = $_SESSION['day'];
        $_MONTH = $_SESSION['month'];
        $_YEAR = $_SESSION['year'];
        $_SERVER = $_SESSION['server'];


	$conn = mysqli_connect("localhost","root","","monitor");

	$sqlQuery = "SELECT * FROM cpu WHERE year='$_YEAR' AND server='$_SERVER' AND month='$_MONTH' AND day='$_DAY' ORDER BY hour ASC";

	$result = mysqli_query($conn,$sqlQuery);

	$data = array();
	foreach ($result as $row) {
		$data[] = $row;
	}

	mysqli_close($conn);

	echo json_encode($data);

?>
