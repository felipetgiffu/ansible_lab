<?php
	phpinfo()

?> 
