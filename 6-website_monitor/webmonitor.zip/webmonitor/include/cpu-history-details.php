<style>

	.title {
		font-family: "Ubuntu";
        	font-size: 30px;
		font-weight: bold;
		padding-bottom: 20px;
		text-align: center;
	}

	#home-content {
                font-family: "Ubuntu";
                width: 880px;
        }

	#home-content a {
  		background-color: #c0c0c0;
		border: 3px solid #000000;
		border-radius: 10px;
  		color: #000000;
		display: block;
		font-weight: bold;
		margin-bottom: 5px;
		padding-bottom: 5px;
		padding-top: 5px;
		text-align: center;
	  	text-decoration: none;
	}

	#home-content a:hover, #home-content a:active {
  		background-color: #000000;
		color: #ffffff;
	}
	
	h3 {
		font-size: 24px;
		margin-top: -10px;
		text-align: center;
	}

	h4 {
		font-size: 20px;
                margin-top: 10px;
                text-align: center;
	}

</style>

<script type="text/javascript" src="graphic/js/jquery.min.js"></script>
<script type="text/javascript" src="graphic/js/Chart.min.js"></script>

<?php
	session_start();

        $_DAY = $_GET['day'];
        $_MONTH = $_GET['month'];
        $_YEAR = $_GET['year'];
        $_SERVER = $_GET['server'];

        $_SESSION['day'] = $_DAY ;
        $_SESSION['month'] = $_MONTH ;
        $_SESSION['year'] = $_YEAR ;
        $_SESSION['server'] = $_SERVER ;

	require_once 'connection/connectDB.php';
?>

<div class=title>
	<?php echo $_SERVER; ?> - Histórico de CPU
</div>
	
<h3>Dia: <?php echo $_DAY; echo "/"; echo $_MONTH; echo "/"; echo $_YEAR; ?></h3>

<div id=home-content>

	<table border=0 width=100% align=center>
		<tr bgcolor=000000 style="color:ffffff">
              		<td colspan=7>&nbsp;</td>
        	</tr>
        	<tr bgcolor=c0c0c0 style="color:000000">
     	      		<td align=center width=40%><b>HORA DO SERVIDOR</b></td>
               		<td align=center width=30%><b>TOTAL</b></td>
               		<td align=center width=30%><b>USADO</b></td>
        	</tr>

		<?php
			$_avgCPU = 0;
			$_totalHOUR = 0;
						

			$sql = "SELECT * FROM cpu WHERE year='$_YEAR' AND server='$_SERVER' AND month='$_MONTH' AND day='$_DAY' ORDER BY hour DESC";
        		if($result = mysqli_query($link, $sql)){
                		if(mysqli_num_rows($result) > 0){
                			while($row = mysqli_fetch_array($result)){
						$_avgCPU = $_avgCPU + $row['usedcpu'];
						$_totalHOUR ++;
		?>

		<tr>
			<td bgcolor=f1f2f3 align=center>
                      	        <?php echo $row['hour']; ?>
                        </td>
                        <td bgcolor=f1f2f3 align=center>
                               	<?php echo $row['totalcpu']; ?>
                        </td>
                        <td bgcolor=f1f2f3 align=center>
                                <?php echo $row['usedcpu']; ?>%
                        </td>
                </tr>
		<?php
        		}
                		mysqli_free_result($result);
                		} else {
                			echo "No records matching your query were found.";
                		}
        				} else {
                				echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
        					}
						?>
						<tr bgcolor=c0c0c0>
							<td colspan=3>
								&nbsp;
							</td>
						</tr>	
						<tr bgcolor=f1f2f3 align=center>
                                                        <td colspan=2>
                                                            	<b>Média de CPU usada</b>
                                                        </td>
							<td>
                                                                <?php echo number_format($_avgCPU/$_totalHOUR, 2, '.', ''); ?>%
                                                        </td>
                                                </tr>
						<?php						
                                                        $sql = "SELECT * FROM baseline WHERE server='$_SERVER'";
                                                        if($result = mysqli_query($link, $sql)){
                                                                if(mysqli_num_rows($result) > 0){
                                                                        while($row = mysqli_fetch_array($result)){
                                                                        	echo "<tr>";
                                                                                	echo "<td colspan=2>";
											echo "<br>";

                                                                                	if($row['os'] == "AIX") {
                                                                                	?>
                                                                                        	<a href="monitorServer-aix.php?server=<?php echo $row['server'];?>">Click here to see the server details</a>
                                                                                	<?php
                                                                                	} else {
                                                                                	?>
                                                                                        	<a href="monitorServer-linux.php?server=<?php echo $row['server'];?>">Click aqui para ver os detalhes do servidor</a>
                                                                                	<?php
                                                                                	}
                                                                                	echo "</td>";
											echo "<td colspan=1>";
												echo "<br>";
												?><a href="exportcpu.php?server=<?php echo $_SERVER;?>&year=<?php echo $_YEAR;?>&month=<?php echo $_MONTH; ?>&day=<?php echo $_DAY; ?>" target="_blank">Exportar dados para Excel</a><?php
											echo "</td>";
                                                                                	echo "<tr>";
                                                                        	}
                                                                }
                                                                mysqli_free_result($result);
                                                 	} else {
                                                                        echo "No records matching your query were found.";
        	                                  }
			?>
      		</tr>
	</table>

	<br><br><br>
<h3>CPU usada (em %)</h3>
<div id="chart-cpu">
<canvas id="graphCanvasCPU"></canvas>
</div>

<script>
	$(document).ready(function () {
		showGraph();
	});
	
	function showGraph()
	{
		{
			$.post("graphic/data_cpu.php",
			function (data)
			{
				console.log(data);
				var HOUR = [];
				var CPU = [];

			for (var i in data) {
				HOUR.push(data[i].hour);
				CPU.push(data[i].usedcpu);
			}
						
			var options = {
				legend: {
					display: false
				},
				scales: {
					xAxes: [{
						display: true
					}],
					yAxes: [{
						ticks: {
						beginAtZero: true
						}
					}]
				}
			};
	
			var chartdata = {
				labels: HOUR,
				datasets: [
				{
					label: 'CPU used (in %)',
					backgroundColor: '#49e2ff',
					borderColor: '#46d5f1',
					hoverBackgroundColor: '#c0c0c0',
					hoverBorderColor: '#666666',
					data: CPU
				}
				]
			};

			var graphTarget = $("#graphCanvasCPU");
			var barGraph = new Chart(graphTarget, {
				type: 'bar',
				data: chartdata,
				options: options
			});
		});
		}
		}
	</script>
	<br><br><br>

</div>
