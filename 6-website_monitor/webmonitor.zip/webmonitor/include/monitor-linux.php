<style>

	.title {
		font-family: "Ubuntu";
        	font-size: 30px;
		font-weight: bold;
		padding-bottom: 20px;
		text-align: center;
	}

	#home-content {
                font-family: "Ubuntu";
                width: 880px;
        }

	#home-content table {
		margin-left: auto;
		margin-right: auto;
		text-decoration: none;
		width: 94%;
	}

	#home-content table tr td a {
  		background-color: #c0c0c0;
		border: 3px solid #000000;
		border-radius: 10px;
  		color: #000000;
		display: block;
		font-weight: bold;
		margin-bottom: 5px;
		padding-bottom: 5px;
		padding-top: 5px;
		text-align: center;
	  	text-decoration: none;
	}

	#home-content table tr td a:hover, #home-content table tr td a:active {
  		background-color: #000000;
		color: #ffffff;
	}
	
	#home-content table tr th .ItemTitle {
                font-size: 20px;
        }

<?php
        $server_name = $_GET['server'];

	require_once 'connection/connectDB.php';
?>

</style>
<div class=title>
	<?php echo $server_name; ?> - Detalhes do servidor
</div>

	<?php
	
                $sql = "SELECT * FROM hostdetails WHERE server='$server_name'";

		if($result = mysqli_query($link, $sql)){
                                if(mysqli_num_rows($result) > 0){
                                        while($row = mysqli_fetch_array($result)){

	?>
<div id=home-content>
	<table border=0 width=100% align=center>
		<tr bgcolor=000000 style="color:ffffff">
			<td colspan=2>&nbsp;</td>
		</tr>
		<tr>
                        <td width=30% bgcolor=c0c0c0>
                                <b>Data último scan</b>
                        </td>
                        <td width=80% bgcolor=f2f3f4>
				<?php echo $row['date'];?>
                        </td>
                </tr>
		<tr>
			<td width=30% bgcolor=c0c0c0>
				<b>Hostname</b>
			</td>
			<td width=80% bgcolor=f2f3f4>
				<?php echo $row['server'];?>
			</td>
		</tr>
		<tr>
                        <td width=30% bgcolor=c0c0c0>
                                <b>Nome Sistema</b>
                        </td>
                        <td width=80% bgcolor=f2f3f4>
				<?php echo $row['osname'];?>
                        </td>
                </tr>
		<tr>
                        <td width=30% bgcolor=c0c0c0>
                                <b>Versão do Sistema</b>
                        </td>
                        <td width=80% bgcolor=f2f3f4>
				<?php echo $row['osversion'];?>
                        </td>
                </tr>
		<tr>
                        <td width=30% bgcolor=c0c0c0>
                                <b>Plataforma do hardware</b>
                        </td>
                        <td width=80% bgcolor=f2f3f4>
				<?php echo $row['platform'];?>
                        </td>
                </tr>
		<tr>
                        <td width=30% bgcolor=c0c0c0>
                                <b>Endereço de IP</b>
                        </td>
                        <td width=80% bgcolor=f2f3f4>
				<?php echo $row['ip'];?>
                        </td>
                </tr>
		<tr>
                        <td width=30% bgcolor=c0c0c0>
                                <b>Versão do Kernel</b>
                        </td>
                        <td width=80% bgcolor=f2f3f4>
				<?php echo $row['kernel'];?>
                        </td>
                </tr>
		<tr>
                        <td width=30% bgcolor=c0c0c0>
                                <b>Número de CPU</b>
                        </td>
                        <td width=80% bgcolor=f2f3f4>
				<?php echo $row['cpu'];?>
                        </td>
                </tr>
		<tr>
                        <td width=30% bgcolor=c0c0c0>
                                <b>Média de uso da CPU</b>
                        </td>
                        <td width=80% bgcolor=f2f3f4>
				<?php echo $row['cpuavg'];?>
                        </td>
                </tr>
		<tr>
                        <td width=30% bgcolor=c0c0c0>
                                <b>Uptime</b>
                        </td>
                        <td width=80% bgcolor=f2f3f4>
				<?php echo $row['uptime'];?>
                        </td>
		</tr>
		<tr>
                        <td width=30% bgcolor=c0c0c0>
                                <b>Usuários logados</b>
                        </td>
                        <td width=80% bgcolor=f2f3f4>
				<?php echo $row['userlog'];?>
                        </td>
                </tr>
		<tr>
                        <td width=30% bgcolor=c0c0c0>
                                <b>Média de uso do sistema</b>
                        </td>
                        <td width=80% bgcolor=f2f3f4>
				<?php echo $row['load_avg'];?>
                        </td>
		</tr>
		<tr>
                        <td width=30% bgcolor=c0c0c0>
                                <b>SSH Status</b>
                        </td>
                        <td width=80% bgcolor=f2f3f4>
				<?php echo $row['ssh'];?>
                        </td>
                </tr>
	</table>
	<br>
	</table>
	<br>
	<table border=0 width=100% align=center>
		<tr style="color:ffffff; font-size:20px; font-weight: bold" bgcolor=000000 align=center>
                        <td colspan=3>
                                MEMORIA RAM E SWAP
                        </td>
                </tr>
                <tr bgcolor=000000 style="color:ffffff" align=center>
			<th width=30%>
                                MEMORIA
                        </th>
                        <th width=15%>
                                TOTAL
                        </th>
                        <th width=15%>
                                USADA
                        </th>
		</tr>
		<tr align=center>
			<td bgcolor=c0c0c0 align=center>
                                <b>RAM</b>
                        </td>
                        <td bgcolor=f2f3f4>
				<?php echo $row['ramtotal'];?>
                        </td>
                        <td bgcolor=f2f3f4>
				<?php echo $row['ramused'];?>
                        </td>
		</tr>
		<tr align=center>
                        <td bgcolor=c0c0c0 align=center>
                                <b>SWAP</b>
                        </td>
                        <td bgcolor=f2f3f4>
				<?php echo $row['swaptotal'];?>
                        </td>
                	<td bgcolor=f2f3f4>
				<?php echo $row['swapused'];?>
                        </td>
           	</tr>
		<tr>
                        <td colspan=4>
                                <a href=memory-history-year.php?os=REDHAT&server=<?php echo $server_name ?>>Clique aqui para acessar o histórico de uso da memória</a>
                        </td>
                </tr>
	</table>
	<br><br>
	<table border=0 width=100% align=center>
                <tr style="color:ffffff; font-size:20px; font-weight: bold" bgcolor=000000 align=center>
                        <td colspan=5>
                                Sistemas de Arquivos - Detalhes
                        </td>
			<tr bgcolor=000000 style="color:ffffff" bgcolor=c0c0c0 align=center>
               		<th width=30%>
                      		SISTEMA DE ARQUIVO
               		</th>
              		<th width=12%>
                       		TAMANHO
               		</th>
               		<th width=12%>
                       		USADO
              		</th>
			<th width=12%>
                                DISPONÍVEL
                        </th>
                	<th width=12%>
                       		% USADO
                	</th>
		</tr>
			<?php
				$xml = simplexml_load_file("xml/$server_name-filesystem.xml");
         		    	foreach($xml->filesystem as $fsystem){
			?>
		<tr align=center bgcolor=FFFFFF style="color:000000">
			<td bgcolor=f2f3f4 style="color:000000">   
                                <?php
                                        echo $fsystem->fs->name;
                                ?>
                        </td>
			<td bgcolor=f2f3f4 style="color:000000">    
                                <?php
                                        echo $fsystem->fs->size;
                                ?>
                        </td>
			<td bgcolor=f2f3f4 style="color:000000">
                                <?php
                                        echo $fsystem->fs->used;
                                ?>
                        </td>
			<td bgcolor=f2f3f4 style="color:000000">    
                        	<?php
                                        echo $fsystem->fs->available;
                                ?>
                        </td>
			<td bgcolor=f2f3f4 style="color:000000">    
                                <?php
                                        echo $fsystem->fs->percUsed;
                                ?>%
                        </td>	
		</tr>
			<?php
					}
			?>



	</table>


</div>

<?php
			}
		}
	}

?>

