<style>

	.title {
		font-family: "Ubuntu";
        	font-size: 30px;
		font-weight: bold;
		padding-bottom: 20px;
		text-align: center;
	}

	#home-content {
                font-family: "Ubuntu";
                width: 880px;
        }

	#home-content table {
		margin-left: auto;
		margin-right: auto;
		text-decoration: none;
		width: 94%;
	}

	#home-content table tr td a {
  		background-color: #c0c0c0;
		border: 3px solid #000000;
		border-radius: 10px;
  		color: #000000;
		display: block;
		font-weight: bold;
		margin-bottom: 5px;
		padding-bottom: 5px;
		padding-top: 5px;
		text-align: center;
	  	text-decoration: none;
	}

	#home-content table tr td a:hover, #home-content table tr td a:active {
  		background-color: #000000;
		color: #ffffff;
	}
	
	#home-content table tr th .ItemTitle {
                font-size: 20px;
        }

	<?php
		require_once 'connection/connectDB.php';	
	?>

</style>
<div class=title>
	File systems listed below has more 80% used
</div>

<div id=home-content>

	<table border=0 width=100% align=center>
		<tr bgcolor=000000 style="color:ffffff" bgcolor=c0c0c0 align=center>
              		<th width=22%>
                       		SERVER
               		</th>
               		<th width=30%>
                      		FILE SYSTEM
               		</th>
              		<th width=12%>
                       		SIZE
               		</th>
               		<th width=12%>
                       		USED
              		</th>
			<th width=12%>
                                AVAILABLE
                        </th>
                	<th width=12%>
                       		% USED
                	</th>
		</tr>
		<?php
                	$sql = "SELECT * FROM baseline ORDER BY server ASC";				
			
			if($result = mysqli_query($link, $sql)){
                                if(mysqli_num_rows($result) > 0){
                                        while($row = mysqli_fetch_array($result)){
						$_SERVER = $row['server'];

						$xml = simplexml_load_file('xml/rhel-ansible-host1-filesystem.xml');
         		    			foreach($xml->filesystem as $fsystem){
                        	        		if ($fsystem->fs->percUsed >= "20") {
		?>
		<tr align=center bgcolor=FF4000 style="color:ffffff">
			<td>
				<?php
                                	echo $row['server'];
                                ?>
			</td>
			<td>   
                                <?php
                                        echo $fsystem->fs->name;
                                ?>
                        </td>
			<td>    
                                <?php
                                        echo $fsystem->fs->size;
                                ?>
                        </td>
			<td>
                                <?php
                                        echo $fsystem->fs->used;
                                ?>
                        </td>
			<td>    
                        	<?php
                                        echo $fsystem->fs->free;
                                ?>
                        </td>
			<td>    
                                <?php
                                        echo $fsystem->fs->percUsed;
                                ?>%
                        </td>	
		</tr>
		<?php
                	}
			if ($fsystem->fs->percUsed >= "80" && $fsystem->fs->percUsed < "85"  ) {
                ?>
                <tr align=center bgcolor=ffffff>
                        <td>    
                	        <?php
                			echo $row['server'];
                                ?>
                        </td>   
                        <td> 
                                <?php
                                        echo $fsystem->fs->name;
                                ?>
                        </td> 
                        <td> 
                                <?php
                                        echo $fsystem->fs->size;
                                ?>
                        </td> 
                        <td> 
                                <?php
                                        echo $fsystem->fs->used;
                                ?>
                        </td>
			<td>
                                <?php
                                        echo $fsystem->fs->free;
                                ?>
                        </td> 
                        <td> 
                                <?php
                                        echo $fsystem->fs->percUsed;
                                ?>%
                        </td>   
           	</tr>
                <?php
							}
                        	                }
               				}
               			}
       			}
       			fclose($fileServer);
		?>
	</table>
</div>
