<style>

	.title {
		font-family: "Ubuntu";
        	font-size: 30px;
		font-weight: bold;
		margin-bottom: 20px;
		text-align: center;
	}

	.title p {
                font-family: "Ubuntu";
                font-size: 20px;
                font-weight: bold;
                margin-bottom: 20px;
                text-align: center;
        }

	#home-content {
                font-family: "Ubuntu";
                width: 880px;
        }

	#home-content table {
		margin-left: auto;
		margin-right: auto;
		text-decoration: none;
		width: 100%;
	}

	#home-content table tr td a {
  		background-color: #c0c0c0;
		border: 3px solid #000000;
		border-radius: 10px;
  		color: #000000;
		display: block;
		font-weight: bold;
		margin-bottom: 5px;
		padding-bottom: 5px;
		padding-top: 5px;
		text-align: center;
	  	text-decoration: none;
	}

	#home-content table tr td a:hover, #home-content table tr td a:active {
  		background-color: #000000;
		color: #ffffff;
	}

	#home-content table tr th {
		margin-bottom: 10px;
	}
	
	#home-content table tr th .ItemTitle {
                font-size: 20px;
        }
	
	#home-content table tr th .envtype {
                font-size: 20px;
        }

<?php
	require_once 'connection/connectDB.php';
	$_DAY = date("d");
        $_MONTH = date("m");
        $_YEAR = date("Y");
?>

</style>
<div class=title>
	CPU - Histórico de uso
	<p>Selecione o servidor para ver o histórico de cpu utilizada</p>
</div>

<div id=home-content>

			<table width=90%>
				<tr>
                        		<td>&nbsp;</td>
                                </tr>
				<tr>
                                	<th align=center colspan=3>
						<div class=envtype>PROD</div>
					</th>
                                </tr>
				<?php
                                	$servercount=1;

                                        $sql = "SELECT * FROM baseline WHERE os='REDHAT' and env='PROD' ORDER BY server ASC";

                                        if($result = mysqli_query($link, $sql)){
                                        	if(mysqli_num_rows($result) > 0){
                                                	while($row = mysqli_fetch_array($result)){
                                                        	if($servercount == 1) {
                                                                	echo "<tr>";
                                                                }
							?>
                                                                <td width=3,3% align=center>
                                                                	<a href=cpu-history-year.php?os=LINUX&server=<?php echo $row['server'];?>><?php echo $row['server'];?></a>
                                                                </td>
							<?php
                                                                if($servercount == 3) {
                                                                	echo "<tr>";
                                                                        $servercount=0;
                                                                }
                                                                $servercount ++;
                                                        }
                                                      	mysqli_free_result($result);
                                               	} else {
                                             		echo "No records matching your query were found.";
                                        	}
                               		} else {
                                               	echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                                        }
				?>
				<tr>
                                	<td>&nbsp;</td>
                                </tr>
                                <tr>
                                        <th align=center colspan=3>
						<div class=envtype>DEV</div>
					</th>
                                </tr>
				<?php
					$servercount=1;

                                        $sql = "SELECT * FROM baseline WHERE os='REDHAT' AND env='DEV' ORDER BY server ASC";

                                        if($result = mysqli_query($link, $sql)){
                                                if(mysqli_num_rows($result) > 0){
                                                        while($row = mysqli_fetch_array($result)){
                                                                if($servercount == 1) {
                                                                        echo "<tr>";
                                                                }
                                                        ?>
                                                                <td width=3,3% align=center>
                                                                        <a href=cpu-history-year.php?os=LINUX&server=<?php echo $row['server'];?>><?php echo $row['server'];?></a>
                                                                </td>
                                                        <?php
                                                                if($servercount == 3) {
                                                                        echo "<tr>";
                                                                        $servercount=0;
                                                                }
                                                                $servercount ++;
                                                        }
                                                        mysqli_free_result($result);
                                                } else {
                                                        echo "No records matching your query were found.";
                                                }
                                        } else {
                                                echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                                        }



                        	?>
                	</table>


</div>
