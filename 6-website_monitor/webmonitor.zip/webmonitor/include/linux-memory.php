<style>

	.title {
		font-family: "Ubuntu";
        	font-size: 30px;
		font-weight: bold;
		margin-bottom: 20px;
		text-align: center;
	}

	#home-content {
                font-family: "Ubuntu";
                width: 880px;
        }

	#home-content table {
		margin-left: auto;
		margin-right: auto;
		text-decoration: none;
		width: 100%;
	}

	#home-content table tr td a {
  		background-color: #c0c0c0;
		border: 3px solid #000000;
		border-radius: 10px;
  		color: #000000;
		display: block;
		font-weight: bold;
		margin-bottom: 5px;
		padding-bottom: 5px;
		padding-top: 5px;
		text-align: center;
	  	text-decoration: none;
	}

	#home-content table tr td a:hover, #home-content table tr td a:active {
  		background-color: #000000;
		color: #ffffff;
	}
	
	#home-content table tr th .ItemTitle {
                font-size: 20px;
        }

<?php
	require_once 'connection/connectDB.php';
	$_DAY = date("d");
        $_MONTH = date("m");
        $_YEAR = date("Y");
?>

</style>
<div class=title>
	Memória - Detalhes do último scan
</div>

<div id=home-content>

	<table border=0 align=center>
		<tr bgcolor=000000 style="color:ffffff">
                        <td colspan=8>&nbsp;</td>
                </tr>
		<tr bgcolor=c0c0c0 style="color:000000">
                        <td colspan=1>&nbsp;</td>
			<td colspan=3 align=center><b>RAM</b></td>
			<td colspan=3 align=center><b>SWAP</b></td>
                </tr>
                <tr align=center>
			<td width=22% bgcolor=c0c0c0>
                                <b>Servidor</b>
                        </td>
                        <td width=11% bgcolor=c0c0c0>
                                <b>Total (MB)</b>
                        </td>
                        <td width=11% bgcolor=c0c0c0>
                                <b>Usado (MB)</b>
                        </td>
			<td width=10% bgcolor=c0c0c0>
                                <b>% Usado</b>
                        </td>
			<td width=11% bgcolor=c0c0c0>
                                <b>Total (MB)</b>
                        </td>
                        <td width=11% bgcolor=c0c0c0>
                                <b>Usado (MB)</b>
                        </td>
			<td width=10% bgcolor=c0c0c0>
                                <b>% Usado</b>
                        </td>
                </tr>
		<tr>
                        <td>&nbsp;</td>
                </tr>
		<tr bgcolor=c0c0c0>
			<th align=center colspan=8>PROD</th>
		</tr>
		<?php
			$sql = "SELECT server FROM baseline WHERE os='REDHAT' and env='PROD' ORDER BY server ASC";

                       	if($result = mysqli_query($link, $sql)){
                               	if(mysqli_num_rows($result) > 0){
					while($row = mysqli_fetch_array($result)){
						$_SERVER = $row['server'];

						$sql2="SELECT * FROM memory WHERE server='$_SERVER' ORDER by id DESC limit 1";
						if($result2 = mysqli_query($link, $sql2)){
                                			if(mysqli_num_rows($result2) > 0){
                                        			while($row2 = mysqli_fetch_array($result2)){
			?>
									<tr>
										<td>
											<div class=linkServer>
												<a href=memory-history-year.php?os=<?php echo $row2['server'];;?>&server=<?php echo $row2['server'];?>><?php echo $row2['server'];?></a>
											</div>
										</td>
										<td bgcolor=f1f2f3 align=center>
                               								<?php echo $row2['totalram'];?>
                       								</td>
                       								<td bgcolor=f1f2f3 align=center>
                               								<?php echo $row2['usedram'];?>
                       								</td>
										<td bgcolor=f1f2f3 align=center>
                                                               				<?php 
												$percRAM = ($row2['usedram']/$row2['totalram'])*100;
												echo $percRAM = number_format($percRAM, 2, '.', ''); echo "%" ;
											?>
                                                        			</td>
										<td bgcolor=f1f2f3 align=center>
                                                                			<?php echo $row2['totalswap'];?>
                                                        			</td>
                                                        			<td bgcolor=f1f2f3 align=center>
                                                                			<?php echo $row2['usedswap'];?>
                                                        			</td>
										<td bgcolor=f1f2f3 align=center>
											<?php 
                                                                        			$percSWAP = ($row2['usedswap']/$row2['totalswap'])*100;
                                                                        			echo $percSWAP = number_format($percSWAP, 2, '.', ''); echo "%" ;
                                                                			?>                                                                        
                                                        			</td>
									</tr>
		<?php
								}
							}
						}
                                        }
                                }
                        }
			?>
				<tr bgcolor=c0c0c0>
                        		<th align=center colspan=8>DEV</th>
                		</tr>
			<?php
                        $sql = "SELECT server FROM baseline WHERE os='REDHAT' and env='DEV' ORDER BY server ASC";

                        if($result = mysqli_query($link, $sql)){
                                if(mysqli_num_rows($result) > 0){
                                        while($row = mysqli_fetch_array($result)){
                                                $_SERVER = $row['server'];

                                                $sql2="SELECT * FROM memory WHERE server='$_SERVER' ORDER by id DESC limit 1";
                                                if($result2 = mysqli_query($link, $sql2)){
                                                        if(mysqli_num_rows($result2) > 0){
                                                                while($row2 = mysqli_fetch_array($result2)){
                        ?>
                                                                        <tr>
                                                                                <td>
                                                                                        <div class=linkServer>
                                                                                                <a href=memory-history-year.php?os=<?php echo $row2['server'];;?>&server=<?php echo $row2['server'];?>><?php echo $row2['server'];?></a>
                                                                                        </div>
                                                                                </td>
                                                                                <td bgcolor=f1f2f3 align=center>
                                                                                        <?php echo $row2['totalram'];?>
                                                                                </td>
                                                                                <td bgcolor=f1f2f3 align=center>
                                                                                        <?php echo $row2['usedram'];?>
                                                                                </td>
                                                                                <td bgcolor=f1f2f3 align=center>
                                                                                        <?php
                                                                                                $percRAM = ($row2['usedram']/$row2['totalram'])*100;
                                                                                                echo $percRAM = number_format($percRAM, 2, '.', ''); echo "%" ;
                                                                                        ?>
                                                                                </td>
                                                                                <td bgcolor=f1f2f3 align=center>
                                                                                        <?php echo $row2['totalswap'];?>
                                                                                </td>
                                                                                <td bgcolor=f1f2f3 align=center>
                                                                                        <?php echo $row2['usedswap'];?>
                                                                                </td>
                                                                                <td bgcolor=f1f2f3 align=center>
                                                                                        <?php
                                                                                                $percSWAP = ($row2['usedswap']/$row2['totalswap'])*100;
                                                                                                echo $percSWAP = number_format($percSWAP, 2, '.', ''); echo "%" ;
                                                                                        ?>
                                                                                </td>
                                                                        </tr>
                <?php
                                                                }
                                                        }
                                                }
                                        }
                                }
                        }
                ?>
                <tr>
                </tr>
	</table>

</div>
