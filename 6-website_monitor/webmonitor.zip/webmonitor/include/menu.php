<style>

	#menu {
		font-family: "Ubuntu";
		width: 300px;
	}

	#menu table {
		width: 100%;
	}

	#menu table tr th a {
  		background-color: #c0c0c0;
		border: 3px solid #000000;
		border-radius: 10px;
  		color: #000000;
		display: block;
		font-weight: bold;
		margin-bottom: 15px;
		padding-bottom: 15px;
		padding-top: 15px;
		text-align: center;
	  	text-decoration: none;
	}

	#menu table tr th a:hover, #menu table tr th a:active {
  		background-color: #000000;
		color: #ffffff;
	}

</style>
<?php

	require_once 'connection/connectDB.php';

	$sql = "SELECT * FROM menu";

	echo "<div id='menu'>";

		echo "<table>";
                	echo "<tr>";
                        	echo "<th>";

        				if($result = mysqli_query($link, $sql)){
						if(mysqli_num_rows($result) > 0){
        						while($row = mysqli_fetch_array($result)){
                     						$_MENU = $row['item'];
								$_URL = $row['url'];
								echo "<a href='$_URL'>$_MENU</a>";
                       					}
               					}
        				}

				echo "</th>";
			echo "</tr>";
		echo "</table>";
	echo "</div>";
?>
<br><br><br>
<div id='menu'>
	<table>
		<tr>
			<th>
				<a href="javascript: history.go(-1)">Voltar página anterior</a>
			</th>
		</tr>
	</table>
</div>
