<style>

	.title {
		font-family: "Ubuntu";
        	font-size: 30px;
		font-weight: bold;
		margin-bottom: 20px;
		text-align: center;
	}

	#home-content {
                font-family: "Ubuntu";
                width: 880px;
        }

	#home-content table {
		margin-left: auto;
		margin-right: auto;
		text-decoration: none;
		width: 100%;
	}

	#home-content table tr td a {
  		background-color: #c0c0c0;
		border: 3px solid #000000;
		border-radius: 10px;
  		color: #000000;
		display: block;
		font-weight: bold;
		margin-bottom: 5px;
		padding-bottom: 5px;
		padding-top: 5px;
		text-align: center;
	  	text-decoration: none;
	}

	#home-content table tr td a:hover, #home-content table tr td a:active {
  		background-color: #000000;
		color: #ffffff;
	}
	
	#home-content table tr th .ItemTitle {
                font-size: 20px;
        }

<?php
	require_once 'connection/connectDB.php';
	$_DAY = date("d");
        $_MONTH = date("m");
        $_YEAR = date("Y");
?>

</style>
<div class=title>
	CPU - Detalhes do último scan
</div>

<div id=home-content>

		<table border=0 width=100% align=center>

			<tr bgcolor=000000 style="color:ffffff">
                                <td colspan=4>&nbsp;</td>
                        </tr>
			<tr bgcolor=c0c0c0 style="color:000000">
                                <td align=center width=40%><b>SERVIDOR</b></td>
				<td align=center width=20%><b>TOTAL</b></td>
				<td align=center width=20%><b>% USADO</b></td>
				<td align=center width=20%></td>
                        </tr>
			<tr>
                                <td>&nbsp;</td>
                        </tr>
			<tr bgcolor=c0c0c0>
				<th align=center colspan=4>PROD</th>
			</tr>
		
			<?php

				$sql = "SELECT server FROM baseline WHERE os='REDHAT' and env='PROD' ORDER BY server ASC";

                             	if($result = mysqli_query($link, $sql)){
                                	if(mysqli_num_rows($result) > 0){
						while($row = mysqli_fetch_array($result)){
							$_SERVER = $row['server'];
							
							$sql2="SELECT * FROM cpu WHERE server='$_SERVER' ORDER by id DESC limit 1";
							if($result2 = mysqli_query($link, $sql2)){
                                				if(mysqli_num_rows($result2) > 0){
                                        				while($row2 = mysqli_fetch_array($result2)){

                	?>
								<tr>
                                					<td bgcolor=f1f2f3>
										<div class=linkServer>
											<a href=cpu-history-year.php?server=<?php echo $row2['server'];?>><?php echo $row2['server'];?></a>
										</div>
                                					</td>
                                					<td bgcolor=f1f2f3 align=center>
                                        					<?php echo $row2['totalcpu'];?>
                                					</td>
                                					<td bgcolor=f1f2f3 align=center>
                                        					<?php echo $row2['usedcpu'];?>
                                					</td>
									<td bgcolor=f1f2f3 align=center>
										<a href=cpu-history-hours-details.php?os=LINUX&server=<?php echo $row2['server'];?>&year=<?php echo $_YEAR;?>&month=<?php echo $_MONTH; ?>&day=<?php echo $_DAY; ?>>Daily report</a>
									</td>
                        					</tr>
			<?php
									}
								}
							}
						}
					}
                                }
			?>
			<tr>
                                <td>&nbsp;</td>
                        </tr>
			<tr bgcolor=c0c0c0>
                                <th align=center colspan=4>DEV</th>
                        </tr>
			<?php
                                $sql = "SELECT * FROM baseline WHERE os='REDHAT' and env='DEV' ORDER BY server ASC";

                                if($result = mysqli_query($link, $sql)){
                                        if(mysqli_num_rows($result) > 0){
                                                while($row = mysqli_fetch_array($result)){
                                                        $_SERVER = $row['server'];

                                                        $sql2="SELECT * FROM cpu WHERE server='$_SERVER' ORDER by id DESC limit 1";
                                                        if($result2 = mysqli_query($link, $sql2)){
                                                                if(mysqli_num_rows($result2) > 0){
                                                                        while($row2 = mysqli_fetch_array($result2)){

                        ?>
                                                                <tr>
                                                                        <td bgcolor=f1f2f3>
                                                                                <div class=linkServer>
                                                                                        <a href=cpu-history-year.php?server=<?php echo $row2['server'];?>><?php echo $row2['server'];?></a>
                                                                                </div>
                                                                        </td>
                                                                        <td bgcolor=f1f2f3 align=center>
                                                                                <?php echo $row2['totalcpu'];?>
                                                                        </td>
                                                                        <td bgcolor=f1f2f3 align=center>
                                                                                <?php echo $row2['usedcpu'];?>
                                                                        </td>
                                                                        <td bgcolor=f1f2f3 align=center>
                                                                                <a href=cpu-history-hours-details.php?os=LINUX&server=<?php echo $row2['server'];?>&year=<?php echo $_YEAR;?>&month=<?php echo $_MONTH; ?>&day=<?php echo $_DAY; ?>>Daily report</a>
                                                                        </td>
                                                                </tr>
                        <?php
                                                                        }
                                                                }
                                                        }
                                                }
                                        }
                                }
                        ?>
			<tr bgcolor=c0c0c0>

			<tr>
                        	<td colspan=4>
					<br>
                                	<b>OBS.: Clique no nome do servidor para acessar o histórico de uso da CPU</b>
                                </td>
                       	</tr>
		</table>

</div>
