<style>

	.title {
		font-family: "Ubuntu";
        	font-size: 30px;
		font-weight: bold;
		padding-bottom: 20px;
		text-align: center;
	}

	#home-content {
                font-family: "Ubuntu";
                width: 880px;
        }

	#home-content a {
  		background-color: #c0c0c0;
		border: 3px solid #000000;
		border-radius: 10px;
  		color: #000000;
		display: block;
		font-weight: bold;
		margin-bottom: 5px;
		padding-bottom: 5px;
		padding-top: 5px;
		text-align: center;
	  	text-decoration: none;
	}

	#home-content a:hover, #home-content a:active {
  		background-color: #000000;
		color: #ffffff;
	}
	
	h3 {
		font-size: 24px;
		margin-top: -10px;
		text-align: center;
	}

	h4 {
		font-size: 20px;
                margin-top: 10px;
                text-align: center;
	}

</style>

<?php
	$server_name = $_GET['server'];

	require_once 'connection/connectDB.php';
?>

<div class=title>
	<?php echo $server_name; ?> - Histórico de CPU
</div>
	
<div id=home-content>

	<h4>Selecione o ano abaixo</h4>

	<?php

        	$sql = "SELECT DISTINCT year FROM cpu WHERE server='$server_name' ORDER BY year DESC";

                if($result = mysqli_query($link, $sql)){
                	if(mysqli_num_rows($result) > 0){
                        	while($row = mysqli_fetch_array($result)){
        ?>
        <a href=cpu-history-month.php?year=<?php echo $row['year']; ?>&server=<?php echo $server_name; ?>><?php echo $row['year']; ?></a>
        <?php
        			}
                		mysqli_free_result($result);
                	} else {
                                echo "No records matching your query were found.";
                	}
           	} else {
                	echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                }

   	?>

</div>
