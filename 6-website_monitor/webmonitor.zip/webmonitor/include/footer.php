<style>

	#footer {
		clear: both;
                display: block;
		font-family: "Ubuntu";
		margin-top: 10px;
		padding-bottom: 10px;
	      	padding-top: 20px;
		width: 100%;
	}

	#footer hr {
		background-color: #000000;
		color: #000000;
		height: 15px;
	}

	#footer p {
		font-weight: bold;
	}

</style>
<div id=footer>
	<hr>
</div>

