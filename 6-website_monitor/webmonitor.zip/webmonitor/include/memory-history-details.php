<style>

	.title {
		font-family: "Ubuntu";
        	font-size: 30px;
		font-weight: bold;
		padding-bottom: 20px;
		text-align: center;
	}

	#home-content {
                font-family: "Ubuntu";
                width: 880px;
        }

	#home-content a {
  		background-color: #c0c0c0;
		border: 3px solid #000000;
		border-radius: 10px;
  		color: #000000;
		display: block;
		font-weight: bold;
		margin-bottom: 5px;
		padding-bottom: 5px;
		padding-top: 5px;
		text-align: center;
	  	text-decoration: none;
	}

	#home-content a:hover, #home-content a:active {
  		background-color: #000000;
		color: #ffffff;
	}
	
	h3 {
		font-size: 24px;
		margin-top: -10px;
		text-align: center;
	}

	h4 {
		font-size: 20px;
                margin-top: 10px;
                text-align: center;
	}

</style>

<script type="text/javascript" src="graphic/js/jquery.min.js"></script>
<script type="text/javascript" src="graphic/js/Chart.min.js"></script>

<?php
	session_start();

        $_DAY = $_GET['day'];
        $_MONTH = $_GET['month'];
        $_YEAR = $_GET['year'];
        $_SERVER = $_GET['server'];
	$_OSVersion = $_GET['os'];

        $_SESSION['day'] = $_DAY ;
        $_SESSION['month'] = $_MONTH ;
        $_SESSION['year'] = $_YEAR ;
        $_SESSION['server'] = $_SERVER ;

	require_once 'connection/connectDB.php';
?>

<div class=title>
	<?php echo $_SERVER; ?> - Histórico de memória
</div>
	
<h3>Dia: <?php echo $_DAY; echo "/"; echo $_MONTH; echo "/"; echo $_YEAR; ?></h3>

<div id=home-content>

	<table border=0 width=100% align=center>
		<tr bgcolor=000000 style="color:ffffff">
                	<td colspan=7>&nbsp;</td>
                </tr>
                <tr bgcolor=c0c0c0 style="color:000000">
                	<td colspan=1>&nbsp;</td>
                	<td colspan=3 align=center><b>RAM</b></td>
                        <td colspan=3 align=center><b>SWAP</b></td>
                </tr>
                <tr align=center>
                        <td width=22% bgcolor=c0c0c0>
                        	<b>Hora do servidor</b>
                        </td>
                        <td width=13% bgcolor=c0c0c0>
                        	<b>Total (MB)</b>
                        </td>
                        <td width=13% bgcolor=c0c0c0>
                        	<b>Usado (MB)</b>
                        </td>
                        <td width=13% bgcolor=c0c0c0>
                        	<b>% Usado</b>
                        </td>
                        <td width=13% bgcolor=c0c0c0>
                          	<b>Total (MB)</b>
                        </td>
                        <td width=13% bgcolor=c0c0c0>
                        	<b>Usado (MB)</b>
                        </td>
                        <td width=13% bgcolor=c0c0c0>
                        	<b>% Usado</b>
                        </td>
           	</tr>

		<?php
			$_avgRAM = 0;
			$_avgRAMPERC = 0;
			$_avgSWAP = 0;
			$_avgSWAPPERC = 0;
			$_totalHOUR = 0;
			
			$sql = "SELECT * FROM memory WHERE year='$_YEAR' AND server='$_SERVER' AND month='$_MONTH' AND day='$_DAY' ORDER BY hour DESC";
        		
			if($result = mysqli_query($link, $sql)){
				if(mysqli_num_rows($result) > 0){
                        		while($row = mysqli_fetch_array($result)){
						$_avgRAM = $_avgRAM + $row['usedram'];
						$_avgSWAP = $_avgSWAP + $row['usedswap'];
						$_totalHOUR ++;
		?>

		<tr>
			<td bgcolor=f1f2f3 align=center>
                      	        <?php echo $row['hour']; ?>
                        </td>
                        <td bgcolor=f1f2f3 align=center>
                               	<?php echo $row['totalram']; ?>
                        </td>
                        <td bgcolor=f1f2f3 align=center>
                                <?php echo $row['usedram']; ?>
                        </td>
                        <td bgcolor=f1f2f3 align=center>
                                <?php
                             	        $percRAM = ($row['usedram']/$row['totalram'])*100;
                                        echo $percRAM = number_format($percRAM, 2, '.', ''); echo "%" ;
					$_avgRAMPERC = $_avgRAMPERC + $percRAM;
                                ?>
                        </td>
                        <td bgcolor=f1f2f3 align=center>
                               	<?php echo $row['totalswap']; ?>
                        </td>
                        <td bgcolor=f1f2f3 align=center>
                                <?php echo $row['usedswap']; ?>
                        </td>
                        <td bgcolor=f1f2f3 align=center>
                                <?php
                              		$percSWAP = ($row['usedswap']/$row['totalswap'])*100;
                                        echo $percSWAP = number_format($percSWAP, 2, '.', ''); echo "%" ;
					$_avgSWAPPERC = $_avgSWAPPERC + $percSWAP;
                                ?>
                        </td>
                        </tr>
				<?php
        	            		}
                				mysqli_free_result($result);
                				} else {
                        				echo "No records matching your query were found.";
                				}
        				} else {
                			echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
        				}
				?>
			<tr bgcolor=c0c0c0>
				<td colspan=7>
					&nbsp;
				</td>
			</tr>	
			<tr bgcolor=f1f2f3 align=center>
                                <td colspan=2>
                                       	<b>Média RAM e SWAP</b>
                                </td>
				<td>
                                        <?php echo number_format($_avgRAM/$_totalHOUR, 2, '.', ''); ?>
                                </td>
				<td>
                                        <?php echo number_format($_avgRAMPERC/$_totalHOUR, 2, '.', ''); ?>%
                                </td>
				<td>
                                      	&nbsp;
                                </td>
				<td>
                                        <?php echo number_format($_avgSWAP/$_totalHOUR, 2, '.', ''); ?>
                                </td>
				<td>
                                        <?php echo number_format($_avgSWAPPERC/$_totalHOUR, 2, '.', ''); ?>%
                                </td>
                         </tr>
			<?php						
                                $sql = "SELECT * FROM baseline WHERE server='$_SERVER'";
                                if($result = mysqli_query($link, $sql)){
                        	        if(mysqli_num_rows($result) > 0){
                                	        while($row = mysqli_fetch_array($result)){
                                                      	echo "<tr>";
                                                       	echo "<td colspan=4>";
							echo "<br>";

                                                     	if($row['os'] == "AIX") {
			?>
                                                             	<a href="monitorServer-aix.php?server=<?php echo $row['server'];?>">Click aqui para ver os detalhes do servidor</a>
                        <?php
                                                      	} else {
                        ?>
                                                             	<a href="monitorServer-linux.php?server=<?php echo $row['server'];?>">Click aqui para ver os detalhes do servidor</a>
                        <?php
                                                       	}
                                                      	echo "</td>";
							echo "<td colspan=3>";
							echo "<br>";
			?>
							<a href="exportmemory.php?server=<?php echo $_SERVER;?>&year=<?php echo $_YEAR;?>&month=<?php echo $_MONTH; ?>&day=<?php echo $_DAY; ?>" target="_blank">Exportar dados para Excel</a>
			<?php
							echo "</td>";
                                			echo "<tr>";
                                		}
                                        }
                                        mysqli_free_result($result);
                                        } else {
                                        	echo "No records matching your query were found.";
                                      	}
			?>
        	</tr>	
	</table>

	<br><br><br>
	<h3>Memória RAM usada (em MB)</h3>
		<div id="chart-ram">
			<canvas id="graphCanvas"></canvas>
		</div>

		<script>
			$(document).ready(function () {
 				showGraph();
			});
	
			function showGraph()
        		{
        			{
        				$.post("graphic/data_ram.php",
        			function (data)
        			{
        				console.log(data);
        				var HOUR = [];
                			var RAM = [];

               				for (var i in data) {
               					HOUR.push(data[i].hour);
               					RAM.push(data[i].usedram);
               				}
						
					var options = {
            					legend: {
                				display: false
            				},
            				scales: {
                				xAxes: [{
                					display: true
                				}],
             					yAxes: [{
                    					ticks: {
                        					beginAtZero: true
                    						}
                					}]
            					}
        				};
	
                    			var chartdata = {
                        			labels: HOUR,
                        			datasets: [
                        			{
                        				label: 'RAM memory used (in MB)',
							backgroundColor: '#49e2ff',
                                                        borderColor: '#46d5f1',
                        				hoverBackgroundColor: '#c0c0c0',
                        				hoverBorderColor: '#666666',
                                			data: RAM
                            			}
                        			]
                    			};

      					var graphTarget = $("#graphCanvas");
       					var barGraph = new Chart(graphTarget, {
               					type: 'bar',
               					data: chartdata,
						options: options
      					});
       				});
			}
		}
	</script>

<br><br><br>
<h3>SWAP usada (em MB)</h3>

<div id="chart-swap">
	<canvas id="graphCanvasSWAP"></canvas>
</div>

<script>
	$(document).ready(function () {
		showGraphSWAP();
	});


	function showGraphSWAP() {
	{
		$.post("graphic/data_swap.php",
		function (data_swap) {
			console.log(data_swap);
			var HOUR = [];
			var SWAP = [];

			for (var i in data_swap) {
				HOUR.push(data_swap[i].hour);
				SWAP.push(data_swap[i].usedswap);
			}

			var chartdata = {
				labels: HOUR,
				datasets: [
				{
					label: 'SWAP used (in MB)',
					backgroundColor: '#49e2ff',
					borderColor: '#46d5f1',
					hoverBackgroundColor: '#CCCCCC',
					hoverBorderColor: '#666666',
					data: SWAP
				}
				]
			};

			var options = {
				legend: {
					display: false
					},
					scales: {
						xAxes: [{
						display: true
						}],
						yAxes: [{
							ticks: {
								beginAtZero: true
							}
						}]
					}
				};

				var graphTarget = $("#graphCanvasSWAP");

				var barGraph = new Chart(graphTarget, {
					type: 'bar',
					data: chartdata,
					options: options
				});
			});
		}
	}
</script>

</div>
