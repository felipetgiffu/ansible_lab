<style>

	.title {
		font-family: "Ubuntu";
        	font-size: 30px;
		font-weight: bold;
		text-align: center;
	}

	#home-content {
                font-family: "Ubuntu";
                width: 880px;
        }

	#home-content table {
		margin-left: auto;
		margin-right: auto;
		text-decoration: none;
		width: 94%;
	}

	#home-content table tr td a {
  		background-color: #c0c0c0;
		border: 3px solid #000000;
		border-radius: 10px;
  		color: #000000;
		display: block;
		font-weight: bold;
		margin-bottom: 5px;
		padding-bottom: 5px;
		padding-top: 5px;
		text-align: center;
	  	text-decoration: none;
	}

	#home-content table tr td a:hover, #home-content table tr td a:active {
  		background-color: #000000;
		color: #ffffff;
	}
	
	#home-content table tr th .ItemTitle {
                font-size: 20px;
        }

	<?php
		require_once 'connection/connectDB.php';	
	?>

</style>
<div class=title>
	LINUX Servers - Baseline
</div>

<div id=home-content>
	<table width=90%>
		<tr>
                        <th colspan=3 height=40px><div class=ItemTitle>PROD</div></th>
                </tr>
           	<?php
                        $servercount=1;
                        $sql = "SELECT * FROM baseline WHERE os='REDHAT' AND env='PROD' ORDER BY server ASC";

                    	if($result = mysqli_query($link, $sql)){
                                if(mysqli_num_rows($result) > 0){
                                        while($row = mysqli_fetch_array($result)){
                                                if($servercount == 1) {
                                                        echo "<tr>";
                			}
           	?>
                                                                <td width=3,3% align=center>
                                                                        <a href="monitorServer-linux.php?server=<?php echo $row['server'];?>"><?php echo $row['server'];?></a>
                						</td>
		<?php
                                                if($servercount == 3) { 
                                        	        echo "</tr>";
                                                $servercount=0;
                                        }
                                        	$servercount ++;
                                        }
                                	mysqli_free_result($result);
                                } else {
                                        echo "No records matching your query were found.";
                        	}
                        } else {
                                echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                	}
                ?>
                <tr>
                	<td>&nbsp;</td>
		</tr>
                <tr>
                        <td>&nbsp;</td>
                </tr>
		<tr>
                        <th colspan=3 height=40px><div class=ItemTitle>DEV</div></th>
                </tr>
                <?php
                        $servercount=1;
                        $sql = "SELECT * FROM baseline WHERE os='REDHAT' AND env='DEV' ORDER BY server ASC";

                        if($result = mysqli_query($link, $sql)){
                                if(mysqli_num_rows($result) > 0){
                                        while($row = mysqli_fetch_array($result)){
                                                if($servercount == 1) {
                                                        echo "<tr>";
                                        }
                ?>
                                                                <td width=3,3% align=center>
                                                                        <a href="monitorServer-linux.php?server=<?php echo $row['server'];?>"><?php echo $row['server'];?></a>
                                                                </td>
                <?php
                                                if($servercount == 3) {
                                                        echo "</tr>";
                                                $servercount=0;
                                        }
                                                $servercount ++;
                                        }
                                        mysqli_free_result($result);
                                } else {
                                        echo "No records matching your query were found.";
                                }
                        } else {
                                echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                        }
                ?>
                <tr>
                        <td>&nbsp;</td>
                </tr>
	</table>
</div>

