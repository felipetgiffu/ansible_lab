<style>
	h1{
		color: #000000;
		font-family: "Ubuntu";
		font-size: 40px;
		margin-top: 20px;
		text-align: center;
	}
	h2{     
                color: #000000;
                font-family: "Ubuntu";
                font-size: 40px;
                text-align: center;
        }
	hr {
		background-color: #000000;
		color: #000000;
		height: 15px;
		margin-top: -10px;
	}
</style>
<?php

	echo "<h2>Red Hat Server monitor - Dashboard</h2>";
	echo "<hr>";
?>

