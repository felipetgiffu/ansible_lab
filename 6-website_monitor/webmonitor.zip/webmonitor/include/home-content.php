<style>

	#home-content {
		font-family: "Arial";
		height: 480px;
		width: 880px;
	}

	#home-content table {
		margin-left: auto;
		margin-right: auto;
		text-decoration: none;
		width: 94%;
	}

	#home-content table tr th a {
  		background-color: #c0c0c0;
		border: 3px solid #000000;
		border-radius: 10px;
  		color: #000000;
		display: block;
		font-size: 24px;
		font-weight: bold;
		margin-bottom: 5px;
		padding-bottom: 15px;
		padding-top: 15px;
		text-align: center;
	  	text-decoration: none;
	}

	#home-content table tr th a:hover, #home-content table tr th a:active {
  		background-color: #000000;
		color: #ffffff;
	}
	
	#home-content table tr th .ItemTitle {
                font-size: 35px;
        }

	#home-content table tr th .menubaseline a {
                padding-bottom: 40px;
		padding-top: 40px;
        }

</style>
		<div id='home-content'>
			<table border=0>
				<tr>
					<th colspan=3><div class=ItemTitle>Baseline - Detalhes</div></th>
				</tr>
				<tr>
                                        <th width=33%><div class=menubaseline><a href='linux-servers.php'>Red Hat</a></div></th>
                                </tr>
				<tr>
                                	<th colspan=3>&nbsp;</th>
                        	</tr>
				<tr>
                                        <th colspan=3>&nbsp;</th>
                                </tr>
			</table>
		</div>
